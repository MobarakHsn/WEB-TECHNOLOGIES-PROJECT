<?php
echo "<header>
<h2>XYZ University Portal</h2>
</header>";
?>