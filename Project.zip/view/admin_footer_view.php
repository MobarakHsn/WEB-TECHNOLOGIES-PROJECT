<?php
echo "<br><br><br>";
echo "<hr>";
echo "<b>";
echo"Call us:+880-XX-NNNN-NNNN/+880-XX-XXXX-XXXX<br>";
echo"Email us:XYZinfo@gamil.com<br>";
echo "&copy" . "2020" . " - " . date("y") . " XYZ University Portal";
echo "</b>";
?>