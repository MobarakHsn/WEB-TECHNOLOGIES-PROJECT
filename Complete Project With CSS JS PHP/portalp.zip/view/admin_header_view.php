<?php
echo "<link rel='stylesheet' type='text/css' href='../css/admin/admin_css.css'>";
echo "<div class='header'>";
echo "<h3>XYZ University Portal</h3></div>";
?>