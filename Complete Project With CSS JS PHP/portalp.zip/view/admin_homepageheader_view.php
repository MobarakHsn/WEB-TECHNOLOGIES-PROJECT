<?php
echo "<link rel='stylesheet' type='text/css' href='../css/admin/admin_css.css'>";
echo "<div class='header'>";
echo "<h3>XYZ University Portal</h3>";
echo "<h4 style='display:none;' id='homename' style='font-style: italic;'>Welcome,".$_SESSION["first_name"]." ".$_SESSION["last_name"]."</h4>";
echo "</div>";
?>