<?php
echo "<link rel='stylesheet' type='text/css' href='../css/admin/admin_css.css'>";
echo "<br><br><br>";
//echo "<hr>";
echo "<div class='footer'>";
echo "<b>";
echo"Call us:+880-XX-NNNN-NNNN/+880-XX-XXXX-XXXX<br>";
echo"Email us:XYZinfo@gamil.com<br>";
echo "&copy" . "2020" . " - " . date("y") . " XYZ University Portal";
echo "</b>";
echo "</div>";
?>