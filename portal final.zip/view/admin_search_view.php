<?php 
echo "hi";
?>